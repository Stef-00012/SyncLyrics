module.exports = (...args) => {
	console.log(...args);
};
