const fs = require("node:fs");
const path = require("node:path");

global.noLyrics = JSON.stringify({
	text: "No Lyrics Avaible",
	alt: "none",
	class: "paused",
	tooltip: "none",
});

global.noSong = JSON.stringify({
	text: "No Song Playing",
	alt: "none",
	class: "paused",
	tooltip: "none",
});

global.noMedia = JSON.stringify({
	text: "No Media Playing",
	alt: "none",
	class: "none",
	tooltip: "none",
});

global.logLevels = {
	debug: 4,
	error: 3,
	warn: 2,
	info: 1,
	none: 0,
};

global.configFolder = path.join(__dirname, 'config')

global.configFile = path.join(configFolder, "config.json");

global.config = {
	logLevel: "none",

	tooltipSourceIncludeCachedNotice: true,
	tooltipMetadataDividerColor: "#ffffff",
	tooltipMetadataArtistColor: "#ffffff",
	tooltipMetadataTrackColor: "#ffffff",
	tooltipMetadataAlbumColor: "#ffffff",
	tooltipCurrentLyricColor: "#cba6f7",
	tooltipPlayerSourceColor: "#89b4fa",
	tooltipIncludeSongMetadata: true,
	tooltipMetadataDivider: "-",

	deleteIconWhenPaused: true,
	iconPath: null,

	ignoredPlayers: ["plasma-browser-integration"],
	favoritePlayers: ["spotify"],
	hatedPlayers: ["chromium"],
	sourceOrder: ["musixmatch", "lrclib"],

	dataUpdateInterval: 1000,
	artistUpdateInterval: 1000,
	nameUpdateInterval: 1000,
	lyricsUpdateInterval: 500,

	marqueeMinLength: 20,
	marqueeDivider: "  ",

	defaultVolumeStep: 5,
};

const functionsDir = path.join(__dirname, "functions");

const functionFiles = fs
	.readdirSync(functionsDir)
	.filter((file) => file.endsWith(".js"));

for (const functionFile of functionFiles) {
	const functionPath = path.join(functionsDir, functionFile);

	const functionData = require(functionPath);
	const functionName = functionFile.split(".").shift();

	global[functionName] = functionData;
}

global.global.currentIntervalType;
global.fetchingMxmToken = false;
global.currentMarqueeIndex = 0;
global.global.fetchingTrackId;
global.lyricsCached = false;
global.lastStoppedPlayer;
global.playerOffset = 0;
global.fetching = false;
global.currentInterval;
global.fetchingSource;
global.currentTrackId;
global.cachedLyrics;
global.lyricsSource;




const lyrics = `[00:08.120] Focus on my breathin', tune out all screamin'
[00:11.560] Tell me, how do you know when something's just past the point of healin'?
[00:15.150] Just couldn't keep it civil, so they put me in the middle
[00:18.490] No, I didn't ask for this
[00:20.990] When we grew up
[00:22.430] We knew too much, too young (Much too young)
[00:26.990] We were just kids, losing our innocence (Innocence)
[00:34.290] We only saw hearts breakin'
[00:39.610] Nothin' like movie scenes, but you're always showin' me
[00:43.570] Love's not pain and
[00:46.830] Patterns don't all repeat, fixin' my broken wings
[00:50.880] Mean it that I'll love you for a lifetimе (Ooh)
[00:54.270] I'm looking in your eyes and I know why, ooh
[00:57.750] Love's not pain and thеre'll be mistakes
[01:03.030] But love's not, love's not pain
[01:05.760] Life can be deceiving, you can't trust what you're seeing
[01:09.170] Never thought that I'd end up with what I always needed
[01:12.990] Like words and vows, but it's real life (No)
[01:14.980] Didn't know it could feel like (Feel like)
[01:16.630] Mixing all of those pastimes (Pastimes)
[01:18.540] When we grew up (Hmm)
[01:20.290] We knew too much, too young (Too much, too young)
[01:24.650] We were just kids, losing our innocence
[01:31.050] We only saw hearts breakin'
[01:37.290] Nothin' like movie scenes, but you're always showin' me
[01:41.320] Love's not pain and
[01:44.500] Patterns don't all repeat, fixin' my broken wings
[01:48.550] Mean it that I'll love you for a lifetime (Ooh)
[01:51.900] I'm looking in your eyes and I know why, ooh
[01:55.510] Love's not pain and there'll be mistakes
[02:00.750] But love's not, love's not pain
[02:03.560] (Love's not pain)
[02:05.010] Love's not (Love's not pain)
[02:08.660] Love's not, love's not
[02:09.960] (Pain, pain)
[02:12.970] Love's not (Pain)
[02:15.490] Love's not, love's not`

const p = parseLyrics(lyrics)

console.log(p)