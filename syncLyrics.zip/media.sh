#!/bin/bash

CONFIG_FOLDER=/home/stef/code/SyncLyrics/config node media.js "$@"